<?php
session_start();

require 'functions.php';

if (isset($_COOKIE['id']) && isset($_COOKIE['key'])) {
    $id = $_COOKIE['id'];
    $key = $_COOKIE['key'];

    $result = mysqli_prepare($conn, "SELECT username FROM user WHERE id = ?");
    mysqli_stmt_bind_param($result, 'i', $id);
    mysqli_stmt_execute($result);
    mysqli_stmt_bind_result($result, $username);
    mysqli_stmt_fetch($result);
    mysqli_stmt_close($result);

    if ($key === hash('sha256', $username)) {
        $_SESSION['login'] = true;
    }
}

if (isset($_SESSION["login"])) {
    header("Location: viewbook.php");
    exit;
}

$error = false;

if (isset($_POST["login"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $result = mysqli_prepare($conn, "SELECT * FROM user WHERE username = ?");
    mysqli_stmt_bind_param($result, 's', $username);
    mysqli_stmt_execute($result);
    $result_set = mysqli_stmt_get_result($result);

    if (mysqli_num_rows($result_set) === 1) {
        $row = mysqli_fetch_assoc($result_set);
        if (password_verify($password, $row["password"])) {
            $_SESSION["login"] = true;

            if (isset($_POST['remember'])) {
                setcookie('id', $row['id'], time() + (86400 * 30)); // Cookie lasts for 30 days
                setcookie('key', hash('sha256', $row['username']), time() + (86400 * 30));
            }

            header("Location: kasirbuku.php");
            exit;
        }
    }
    $error = true;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="login.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script>
        function showError() {
            alert("Wrong username/password");
        }
    </script>
</head>
<body>
    <div class="wrapper">
        <?php if ($error) : ?>
            <script>
                showError();
            </script>
        <?php endif; ?>
        <form action="" method="post">
            <h1>Login Page</h1>
            <div class="input-box">
                <input type="text" name="username" placeholder="username" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="password" name="password" placeholder="password" required>
                <i class='bx bxs-lock-alt'></i>
            </div>
            <div class="remember">
                <label><input type="checkbox" name="remember">Remember me</label>
                <a href="#">Forgot password?</a>
            </div>
            <button type="submit" name="login" class="btn">Login</button>

            <div class="signup-container">
                <p>Don't have an account? <a href="registrasi.php">Register</a></p>
            </div>
        </form>
    </div>
</body>
</html>
