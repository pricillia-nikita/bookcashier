<?php
session_start();

if (!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit;
}

require 'functions.php';
$books = query("SELECT * FROM books");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Book</title>
    <link rel="stylesheet" href="viewbook.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="wrapper">
        <h3>Book(s) List</h3>
        <div class="add-book-button">
            <a href="addbook.php" class="btn">Add Book</a>
        </div>
        <table>
            <tr>
                <th>Action</th>
                <th>ID</th>
                <th>Title</th>
                <th>Author</th>
                <th>Release Year</th>
                <th>Stock</th>
                <th>Price</th>
                <th>Cover</th>
            </tr>
            
            <?php foreach ($books as $book) : ?>
                <tr>
                    <td>
                        <a href="updatebook.php?id=<?= $book["id"]; ?>">Update</a> |
                        <a href="deletebook.php?id=<?= $book["id"]; ?>" onclick="return confirm('Are you sure?');">Delete</a> |
                        <a href="buybook.php?id=<?= $book["id"]; ?>&quantity=1">Buy</a>
                    </td>
                    <td><?= $book["id"]; ?></td>
                    <td><?= $book["title"]; ?></td>
                    <td><?= $book["author"]; ?></td>
                    <td><?= $book["releaseyear"]; ?></td> 
                    <td><?= $book["stock"]; ?></td>
                    <td><?= $book["price"]; ?></td>
                    <td><img src="img/<?= $book["cover"]; ?>" alt="Cover Image"></td>
                </tr>
            <?php endforeach; ?>
        </table>
        <div class="logout-button">
            <a href="logout.php" class="btn">Logout</a>
        </div>
    </div>
</body>
</html>
