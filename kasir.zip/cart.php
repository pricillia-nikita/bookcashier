<?php
session_start(); 

if(!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit;
}

require 'functions.php';

// Initialize the cart session variable if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array(); 
}

// Function to calculate the total price of items in the cart
function calculateTotalPrice($cart) {
    $totalPrice = 0;

    // Loop through each item in the cart and calculate the total price
    foreach ($cart as $id => $quantity) {
        $book = query("SELECT * FROM books WHERE id = '$id'");
        if (!empty($book)) {
            $book = $book[0];
            $price = $book['price']; // Fetch the price of the book

            // Calculate total price for the current book
            $totalPrice += $price * $quantity;
        }
    }

    return $totalPrice;
}

// Check if the form was submitted to update the cart
if (isset($_POST['update']) && isset($_POST['quantity'])) {
    // Update the quantities in the cart
    foreach ($_POST['quantity'] as $id => $quantity) {
        if (isset($_SESSION['cart'][$id])) {
            // Fetch the book details for the current item in the cart
            $book = query("SELECT * FROM books WHERE id = '$id'");
            if (!empty($book)) {
                $book = $book[0];
                $stock = $book['stock']; // Fetch the stock of the book

                // Check if the updated quantity exceeds the available stock
                if ($quantity > $stock) {
                    echo "The quantity of " . $book['title'] . " cannot exceed the available stock.";
                    $quantity = $stock; // Set the quantity to the available stock
                }

                $_SESSION['cart'][$id] = $quantity;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cart</title>
    <link rel="stylesheet" href="cart.css">
</head>
<body>
<div class="wrapper">
    <h3>Shopping Cart</h3>
    <form action="cart.php" method="post">
        <table>
            <tr>
                <th>Title</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
                <th>Cover</th>
                <th>Action</th>
            </tr>
            <?php foreach ($_SESSION['cart'] as $id => $quantity): ?>
                <?php
                // Fetch the book details for the current item in the cart
                $cartBook = query("SELECT * FROM books WHERE id = '$id'");
                if (!empty($cartBook)) {
                    $cartBook = $cartBook[0];
                } else {
                    // Handle the case where the book for the current cart item is not found
                    continue; // Skip to the next cart item
                }
                ?>
                <tr>
                    <td><?= $cartBook["title"]; ?></td> <!-- Display book title -->
                    <td><input type="number" name="quantity[<?= $id ?>]" value="<?= min($quantity, $cartBook['stock']) ?>" min="1" max="<?= $cartBook['stock'] ?>"></td>
                    <td><?= $cartBook["price"]; ?></td>
                    <td>$<?= number_format($cartBook["price"] * $quantity, 2) ?></td> <!-- Calculate total price for the current item -->
                    <td><img src="img/<?= $cartBook["cover"]; ?>"></td>
                    <td><a href="remove.php?id=<?= $id ?>">Remove</a></td>
                </tr>
            <?php endforeach; ?>
        </table>
        <div class="totalprice">
            <p>Total: $<?= number_format(calculateTotalPrice($_SESSION['cart']), 2) ?></p>
        </div>
        <button type="submit" name="update">Update Cart</button>
    </form>
</div>
</body>
</html>
