<?php
session_start();

if(!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit;
}

require 'functions.php';
$books = query("SELECT * FROM books ORDER BY id ASC");

if(isset($_POST["search"])) {
    $books = cari($_POST["keyword"]);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Search Book</title>
    <link rel="stylesheet" href="searchbook.css">
</head>
<body>
<div class="wrapper">
    <h3>Book(s) List</h3>

    <form action = "" method = "post">
        <input type = "text" name = "keyword" size = "61" autofocus placeholder = "Enter the title or author to search..." autocomplete = "off">
        <button type = "submit" name = "search">Search</button>
    </form>
    <table border="1">
        <tr>
            <th>Action</th>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Release Year</th>
            <th>Stock</th>
            <th>Price</th>
            <th>Cover</th>
        </tr>
        
        <?php foreach ($books as $book) : ?>
            <tr>
                <td>
                    <a href = "updatebook.php?id=<?= $book["id"]; ?>">Update</a> |
                    <a href = "deletebook.php?id=<?= $book["id"]; ?>" onclick = "return confirm('Are you sure?');">Delete</a> |
                    <a href="buybook.php?id=<?= $book["id"]; ?>&quantity=1">Buy</a>
                </td>
                <td><?= $book["id"]; ?></td>
                <td><?= $book["title"]; ?></td>
                <td><?= $book["author"]; ?></td>
                <td><?= $book["releaseyear"]; ?></td> 
                <td><?= $book["stock"]; ?></td>
                <td><?= $book["price"]; ?></td>
                <td><img src="img/<?= $book["cover"]; ?>"></td>

            </tr>
        <?php endforeach; ?>
    </table>
</div>
</body>
</html>
