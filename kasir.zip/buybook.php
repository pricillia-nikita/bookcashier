<?php
session_start(); 

if(!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit;
}

require 'functions.php';

$id = $_GET["id"];
$book = query("SELECT * FROM books WHERE id = '$id'");
$book = $book[0];

// Function to add a book to the cart
function addToCart($id, $quantity) {
    // Check if the 'cart' session variable exists, if not, initialize it as an empty array
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }

    // Check if the book is already in the cart
    if (isset($_SESSION['cart'][$id])) {
        // If the book is already in the cart, update the quantity
        $_SESSION['cart'][$id] += $quantity;
    } else {
        // If the book is not in the cart, add it with the specified quantity
        $_SESSION['cart'][$id] = $quantity;
    }
}

// Check if the quantity and book ID are provided via POST
if (isset($_POST['quantity']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $quantity = $_POST['quantity'];

    // Add the book to the cart
    addToCart($id, $quantity);

    // Redirect to the cart page
    header('Location: cart.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Buy Book</title>
    <link rel="stylesheet" href="buybook.css">
    <script>
        function addToCart() {
            var maxQuantity = <?php echo $book['stock']; ?>;
            var quantity = prompt("Enter the quantity (maximum " + maxQuantity + "):", maxQuantity); // Set the prompt with the maximum quantity

            // Check if the user entered a quantity
            if (quantity !== null) {
                // Check if the entered quantity is a positive integer
                if (!isNaN(quantity) && parseInt(quantity) > 0) {
                    // Submit the form with the entered quantity
                    document.getElementById("quantity").value = quantity;
                    document.getElementById("buybookForm").submit();
                } else {
                    alert("Please enter a valid quantity.");
                }
            }
        }
    </script>
</head>
<body>
    <h3>Buy Book</h3>
    <form id="buybookForm" action="buybook.php?id=<?= $_GET['id'] ?>" method="post">
        <input type="hidden" id="quantity" name="quantity">
    </form>

    <!-- Automatically trigger the addToCart function when the page loads -->
    <script>
        window.onload = addToCart;
    </script>
</body>
</html>
