<?php
session_start();

if(!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit;
}

require 'functions.php';

if(isset($_POST["submit"])) {
    if(tambah($_POST) > 0){
        echo "<script>alert('book added')</script>";
    } else {
        echo "<script>alert('book fail added')</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Book</title>
    <link rel="stylesheet" href="addbook.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="wrapper">
        <form action="" id="addBookForm" method="post" enctype="multipart/form-data">
            <h3>Add Book Form</h3>
            <div class="input-box">
                <input type="text" id="title" name="title" placeholder="Title" required>
                <i class='bx bxs-book'></i>
            </div>
            <div class="input-box">
                <input type="text" id="author" name="author" placeholder="Author" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="number" id="releaseyear" name="releaseyear" placeholder="Year of Release" required>
                <i class='bx bxs-calendar'></i>
            </div>
            <div class="input-box">
                <input type="number" id="stock" name="stock" placeholder="Stock" required>
                <i class='bx bxs-layer'></i>
            </div>
            <div class="input-box">
                <input type="number" id="price" name="price" placeholder="Price" required>
                <i class='bx bxs-dollar-circle'></i>
            </div>
            <div class="input-box">
                <input type="file" id="cover" name="cover" required>
                <i class='bx bxs-file-image'></i>
            </div>
            <button type="submit" name="submit" class="btn">Add Book</button>
        </form>
    </div>
</body>
</html>
