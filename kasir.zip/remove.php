<?php
session_start();

if(!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit;
}

// Check if the book ID is provided via GET
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Check if the book exists in the cart
    if (isset($_SESSION['cart'][$id])) {
        // Remove the book from the cart
        unset($_SESSION['cart'][$id]);
    }
}

// Redirect back to the cart page after removing the book
header('Location: cart.php');
exit;
?>
