<?php
require 'functions.php';

if(isset($_POST["register"])) {
    if(registrasi($_POST) > 0){
        echo "<script> alert('New user added'); </script>";
    } else {
        echo mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Page</title>
    <link rel="stylesheet" href="registrasi.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="wrapper">
        <form action="" method="post">
            <h1>Registration Page</h1>
            <div class="input-box">
                <input type="text" name="username" placeholder="Username" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="password" name="password" placeholder="Password" required>
                <i class='bx bxs-lock-alt'></i>
            </div>
            <div class="input-box">
                <input type="password" name="password2" placeholder="Password Confirmation" required>
                <i class='bx bxs-lock-alt'></i>
            </div>
            <label><input type="checkbox"> I hereby declare that above information provided is true and correct</label>
            <button type="submit" name="register" class="btn">Register</button>
        </form>
    </div>
</body>
</html>
