<?php
$conn = mysqli_connect("localhost", "root", "", "kasir");

function query($query) {
    global $conn;
    $result = mysqli_query($conn, $query);

    if (!$result) {
        echo "Error: " . mysqli_error($conn);
        return [];
    }

    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

function tambah($data){
    global $conn;
    $title = mysqli_real_escape_string($conn, $data["title"]);
    $author = mysqli_real_escape_string($conn, $data["author"]);
    $releaseyear = mysqli_real_escape_string($conn, $data["releaseyear"]);
    $stock = mysqli_real_escape_string($conn, $data["stock"]);
    $price = mysqli_real_escape_string($conn, $data["price"]);
    $cover = upload();
    if(!$cover) {
        return false;
    }
    $query = "INSERT INTO books (title, author, releaseyear, stock, price, cover) VALUES ('$title', '$author', '$releaseyear', '$stock', '$price', '$cover')";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function upload() {
    $namafile = $_FILES['cover']['name'];
    $ukuranfile = $_FILES['cover']['size'];
    $error = $_FILES['cover']['error'];
    $temp = $_FILES['cover']['tmp_name'];

    if($error === 4) {
        echo "<script>alert('Choose cover picture!')</script>";
        return false;
    }

    $extensionvldtn = ['jpg', 'jpeg', 'png'];
    $extensioncover = explode('.', $namafile);
    $extensioncover = strtolower(end($extensioncover));

    if(!in_array($extensioncover, $extensionvldtn)) {
        echo "<script>alert('You are not uploading a picture!')</script>";
        return false;
    }

    if($ukuranfile > 1000000) {
        echo "<script>alert('The file size is too big!')</script>";
        return false;
    }

    $namafilebaru = uniqid();
    $namafilebaru .= '.';
    $namafilebaru .= $extensioncover;

    move_uploaded_file($temp, 'img/' . $namafilebaru);

    return $namafilebaru;
}

function hapus($id) {
    global $conn;
    $id = mysqli_real_escape_string($conn, $id); // Escape the ID to prevent SQL injection
    $query = "DELETE FROM books WHERE id = '$id'";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function cari($keyword) {
    $query = "SELECT * FROM books WHERE title LIKE '%$keyword%' OR author LIKE '%$keyword%'";
    return query($query);
}

function ubah($data) {
    global $conn;
    $id = mysqli_real_escape_string($conn, $data["id"]);
    $title = mysqli_real_escape_string($conn, $data["title"]);
    $author = mysqli_real_escape_string($conn, $data["author"]);
    $releaseyear = mysqli_real_escape_string($conn, $data["releaseyear"]);
    $stock = mysqli_real_escape_string($conn, $data["stock"]);
    $price = mysqli_real_escape_string($conn, $data["price"]);
    $coverlama = mysqli_real_escape_string($conn, $data["coverlama"]);
    
    if($_FILES['cover']['error'] === 4) {
        $cover = $coverlama;
    } else {
        $cover = upload();
    }

    $query = "UPDATE books SET title = '$title', author = '$author', releaseyear = '$releaseyear', stock = '$stock', price = '$price', cover = '$cover' WHERE id = '$id'";
    mysqli_query($conn, $query);    
    return mysqli_affected_rows($conn);
}

function registrasi($data) {
    global $conn;
    $username = strtolower(stripslashes($data["username"])); // Corrected field name
    $password = mysqli_real_escape_string($conn, $data["password"]);
    $password2 = mysqli_real_escape_string($conn, $data["password2"]);

    $result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username'"); // Assign the result to $result

    if(mysqli_num_rows($result) > 0) { // Check if a user with the same username already exists
        echo "<script> alert('User already exists!') </script>";
        return false; // Return false to indicate registration failure
    }

    if($password !== $password2) {
        echo "<script> alert('Password tidak sesuai'); </script>";
        return false;
    }

    $password = password_hash($password, PASSWORD_DEFAULT);

    mysqli_query($conn, "INSERT INTO user (username, password) VALUES ('$username', '$password')");

    return mysqli_affected_rows($conn);
}

?>