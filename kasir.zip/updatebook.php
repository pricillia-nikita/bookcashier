<?php
session_start();

if(!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit;
}

require 'functions.php';

$id = $_GET["id"];
$book = query("SELECT * FROM books WHERE id = '$id'");
$book = $book[0];

if(isset($_POST["submit"])) {
    if(ubah($_POST) > 0) {
        echo "<script>
        alert('Book updated successfully!');
        document.location.href = 'viewbook.php';
        </script>";
    } else {
        echo "<script>
        alert('Failed to update book!');
        document.location.href = 'viewbook.php';
        </script>";
    }
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Update Book</title>
        <link rel="stylesheet" href="updatebook.css">
    </head>
    <body>
        <h3>Update Book Form</h3>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $book["id"]; ?>">
            <input type="hidden" name="coverlama" value="<?= $book["cover"]; ?>">

            <label for="title">Title: </label>
            <input type="text" id="title" name="title" value="<?= $book["title"]; ?>">
            <br><br>

            <label for="author">Author: </label>
            <input type="text" id="author" name="author" value="<?= $book["author"]; ?>">
            <br><br>

            <label for="releaseyear">Year of Release: </label>
            <input type="number" id="year" name="releaseyear" value="<?= $book["releaseyear"]; ?>">
            <br><br>

            <label for="stock">Stock: </label>
            <input type="number" id="stock" name="stock" value="<?= $book["stock"]; ?>">
            <br><br>

            <label for="price">Price: </label>
            <input type="number" id="price" name="price" value="<?= $book["price"]; ?>">
            <br><br>
            
            <label for="cover">Cover: </label> <br>
            <img src="img/<?= $book["cover"]; ?>" width ="40"> <br>
            <input type="file" id="cover" name="cover">
            <br><br>

            <button type="submit" name="submit">Update Book</button>
        </form>
    </body>
</html>