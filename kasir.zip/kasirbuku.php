<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Program Kasir Buku</title>
    <link rel="stylesheet" href="kasirbuku.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="wrapper">
        <h1>Program Kasir Buku</h1>
        <hr>
        <div class="dropdown">
            <button class="dropbtn">Menu</button>
            <div class="dropdown-content">
                <a href="addbook.php" class="menu-item">Add Book</a>
                <a href="viewbook.php" class="menu-item">View Book</a>
                <a href="searchbook.php" class="menu-item">Search Book</a>
                <a href="cart.php" class="menu-item">Cart</a>
            </div>
        </div>
    </div>
</body>
</html>
